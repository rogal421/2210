import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function App() {
  const [url, setUrl] = useState('');
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [generatePassword, setGeneratePassword] = useState(true);

  const [summary, setSummary] = useState({
    url: '',
    login: '',
    password: '',
    generatePassword: true,
    isSubmitted: false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setSummary({
      url: url,
      login: login,
      password: password,
      generatePassword: generatePassword,
      isSubmitted: true
    });
  };

  return (
    <div className=" mt-4" style={{ maxWidth: '600px' }}>
      <h1>Menedżer haseł - wykonał 00000000000</h1>

      <form onSubmit={handleSubmit} className="mt-4 mb-4">
        <div className="mb-3">
          <label htmlFor="urlInput" className="form-label">
            Adres WWW:
          </label>
          <input
            type="text"
            className="form-control"
            id="urlInput"
            placeholder="Adres strony WWW"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="loginInput" className="form-label">
            Login:
          </label>
          <input
            type="text"
            className="form-control"
            id="loginInput"
            placeholder="Twój login"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
          />
        </div>

        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            id="generateCheck"
            checked={generatePassword}
            onChange={(e) => setGeneratePassword(e.target.checked)}
          />
          <label className="form-check-label" htmlFor="generateCheck">
            Wygeneruj hasło
          </label>
        </div>

        <div className="mb-3">
          <label htmlFor="passwordInput" className="form-label">
            Hasło:
          </label>
          <input
            type="password"
            className="form-control"
            id="passwordInput"
            disabled={generatePassword}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn btn-primary">
          Zapisz
        </button>
      </form>

      {summary.isSubmitted && (
        <div className="mt-4">
          <p className="p-2 text-primary lead">
            Adres: {summary.url}
          </p>
          <p className="p-2">
            Login: {summary.login}
          </p>
          <p className="p-2">
            {summary.generatePassword
              ? 'Hasło automatycznie generowane'
              : `Hasło: ${summary.password}`}
          </p>
        </div>
      )}
    </div>
  );
}