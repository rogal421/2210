﻿namespace konsolowa
{
    internal class Program
    {
//nazwa funkcji: GenerujHaslo
// opis funkcji: Generuje 5 haseł pod dane kryteria
// parametry: brak
// zwracany typ i opis: string, 5 haseł
// autor: 00000000000
        public static string GenerujHaslo()
        {
            Random random = new Random();
            string malelitery = "abcdefghijklmnopqrstuvwxyz";
            string duzelitery = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string znaki1 = "ąęłńóśżźĄĘŁŃÓŚŻŹ";
            string cyfry = "0123456789";
            string znaki2 = "!@#$%^&*()_+";

            List<char> wylosowaneZnaki = new List<char>();
            for (int i = 0; i < 3; i++)
            {
                int indeks = random.Next(malelitery.Length);
                wylosowaneZnaki.Add(malelitery[indeks]);
            }
            for (int i = 0; i < 3; i++)
            {
                int indeks = random.Next(duzelitery.Length);
                wylosowaneZnaki.Add(duzelitery[indeks]);
            }
            for (int i = 0; i < 2; i++)
            {
                int indeks = random.Next(znaki1.Length);
                wylosowaneZnaki.Add(znaki1[indeks]);
            }
            for (int i = 0; i < 2; i++)
            {
                int indeks = random.Next(cyfry.Length);
                wylosowaneZnaki.Add(cyfry[indeks]);
            }
            for (int i = 0; i < 2; i++)
            {
                int indeks = random.Next(znaki2.Length);
                wylosowaneZnaki.Add(znaki2[indeks]);
            }

            char[] hasloTablica = new char[12];
            for (int i = 0; i < 12; i++)
            {
                int indekslosowy;
                do
                {
                    indekslosowy = random.Next(12);
                }
                while (hasloTablica[indekslosowy] != '\0');
                hasloTablica[indekslosowy] = wylosowaneZnaki[i];
            }

            return new string(hasloTablica);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("GENERATOR HASEŁ\n");
            Console.WriteLine("Wygenerowano 5 haseł");
            Console.WriteLine(new string('-', 45));

            for (int nr = 1; nr <= 5; nr++)
            {
                string haslo = GenerujHaslo();
                Console.WriteLine($"Hasło nr {nr}: {haslo}");
            }
            Console.WriteLine(new string('-', 45));
            Console.WriteLine("\nNaciśnij dowolny klawisz, aby zakończyć...");
            Console.ReadKey();
        }
    }
}
        